Place your onboarding video here as onboarding.mp4

Why here?
- Files under public/ are served statically and available at runtime.
- The app loads /videos/onboarding.mp4 on the onboarding-lite route.

Steps:
1) Copy your MP4 into this folder.
2) Name it exactly: onboarding.mp4
3) Tell me "go" and I will build & deploy a preview.
